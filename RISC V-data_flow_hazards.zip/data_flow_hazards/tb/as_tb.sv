`timescale 1ns/1ps

import as_pack::*;

module as_tb ();

  logic clk_tb;
  logic rst_tb;
  int   cycle_count;

  // IF/ID stage inputs
  logic [4:0]  if_id_rs1_addr_tb;
  logic [4:0]  if_id_rs2_addr_tb;

  // ID/EX stage inputs
  logic [4:0]  id_ex_rs1_addr_tb;
  logic [4:0]  id_ex_rs2_addr_tb;
  logic [4:0]  id_ex_rd_addr_tb;
  logic        id_ex_reg_wr_tb;
  logic        id_ex_mem_rd_tb;

  // EX/MEM stage inputs
  logic [4:0]  ex_mem_rd_addr_tb;
  logic        ex_mem_reg_wr_tb;
  logic        ex_mem_mem_rd_tb;

  // MEM/WB stage inputs
  logic [4:0]  mem_wb_rd_addr_tb;
  logic        mem_wb_reg_wr_tb;

  logic        stall_if_tb;
  logic        stall_id_tb;
  logic        flush_ex_tb;

  //===========================================================================
  // FORWARDING UNIT SIGNALS
  //===========================================================================

  logic [63:0] id_ex_alu_result_tb;
  logic [63:0] ex_mem_alu_result_tb;
  logic [63:0] mem_wb_result_tb;
  
  logic [1:0]  forward_rs1_ctrl_tb;
  logic [1:0]  forward_rs2_ctrl_tb;
  logic [63:0] forward_rs1_data_tb;
  logic [63:0] forward_rs2_data_tb;

  as_hazard_detection_unit hazard_dut (
    .if_id_rs1_addr_i  (if_id_rs1_addr_tb),
    .if_id_rs2_addr_i  (if_id_rs2_addr_tb),
    .id_ex_rs1_addr_i  (id_ex_rs1_addr_tb),
    .id_ex_rs2_addr_i  (id_ex_rs2_addr_tb),
    .id_ex_rd_addr_i   (id_ex_rd_addr_tb),
    .id_ex_reg_wr_i    (id_ex_reg_wr_tb),
    .id_ex_mem_rd_i    (id_ex_mem_rd_tb),
    .ex_mem_rd_addr_i  (ex_mem_rd_addr_tb),
    .ex_mem_reg_wr_i   (ex_mem_reg_wr_tb),
    .ex_mem_mem_rd_i   (ex_mem_mem_rd_tb),
    .mem_wb_rd_addr_i  (mem_wb_rd_addr_tb),
    .mem_wb_reg_wr_i   (mem_wb_reg_wr_tb),
    .stall_if_o        (stall_if_tb),
    .stall_id_o        (stall_id_tb),
    .flush_ex_o        (flush_ex_tb)
  );

  as_forwarding_unit forwarding_dut (
    .if_id_rs1_addr_i  (if_id_rs1_addr_tb),
    .if_id_rs2_addr_i  (if_id_rs2_addr_tb),
    .id_ex_rd_addr_i   (id_ex_rd_addr_tb),
    .id_ex_reg_wr_i    (id_ex_reg_wr_tb),
    .id_ex_alu_result_i(id_ex_alu_result_tb),
    .id_ex_mem_rd_i    (id_ex_mem_rd_tb),
    .ex_mem_rd_addr_i  (ex_mem_rd_addr_tb),
    .ex_mem_reg_wr_i   (ex_mem_reg_wr_tb),
    .ex_mem_alu_result_i(ex_mem_alu_result_tb),
    .ex_mem_mem_rd_i   (ex_mem_mem_rd_tb),
    .mem_wb_rd_addr_i  (mem_wb_rd_addr_tb),
    .mem_wb_reg_wr_i   (mem_wb_reg_wr_tb),
    .mem_wb_result_i   (mem_wb_result_tb),
    .forward_rs1_ctrl_o(forward_rs1_ctrl_tb),
    .forward_rs2_ctrl_o(forward_rs2_ctrl_tb),
    .forward_rs1_data_o(forward_rs1_data_tb),
    .forward_rs2_data_o(forward_rs2_data_tb)
  );

  initial begin
    clk_tb = 1'b0;
    rst_tb = 1'b1;
    #20;
    rst_tb = 1'b0;
    forever #5 clk_tb = ~clk_tb;
  end


  task print_header(input string test_name);
    $display("----------------------------------------------------------");
    $display("TEST: %s", test_name);
    $display("----------------------------------------------------------");
  endtask

  task print_state(input string label);
    $display("[%s] Cycle %0d", label, cycle_count);
    $display("  IF/ID  : rs1_addr=%0d  rs2_addr=%0d",
      if_id_rs1_addr_tb, if_id_rs2_addr_tb);
    $display("  ID/EX  : rd_addr=%0d  rs1_addr=%0d  rs2_addr=%0d  reg_wr=%b  mem_rd=%b",
      id_ex_rd_addr_tb, id_ex_rs1_addr_tb, id_ex_rs2_addr_tb,
      id_ex_reg_wr_tb, id_ex_mem_rd_tb);
    $display("  EX/MEM : rd_addr=%0d  reg_wr=%b  mem_rd=%b",
      ex_mem_rd_addr_tb, ex_mem_reg_wr_tb, ex_mem_mem_rd_tb);
    $display("  MEM/WB : rd_addr=%0d  reg_wr=%b",
      mem_wb_rd_addr_tb, mem_wb_reg_wr_tb);
    $display("  HAZARD : stall_if=%b  stall_id=%b  flush_ex=%b",
      stall_if_tb, stall_id_tb, flush_ex_tb);
    $display("  FORWARD: rs1_ctrl=%b  rs2_ctrl=%b  rs1_data=0x%h  rs2_data=0x%h",
      forward_rs1_ctrl_tb, forward_rs2_ctrl_tb,
      forward_rs1_data_tb, forward_rs2_data_tb);
  endtask


  task verify_hazard(input string desc, input logic expected_stall);
    logic stall_active;
    stall_active = ~stall_id_tb; 
    if (stall_active == expected_stall) begin
      $display("  RESULT : PASS - %s (stall_id_tb=%b, stall_active=%b)",
        desc, stall_id_tb, stall_active);
    end else begin
      $display("  RESULT : FAIL - %s (expected stall_active=%b, got stall_active=%b, stall_id_tb=%b)",
        desc, expected_stall, stall_active, stall_id_tb);
    end
  endtask

  task verify_forward(
    input string       desc,
    input logic [1:0]  expected_ctrl,
    input logic [63:0] expected_data
  );
    if (forward_rs1_ctrl_tb == expected_ctrl &&
        forward_rs1_data_tb == expected_data) begin
      $display("  RESULT : PASS - %s (ctrl=%b, data=0x%h)",
        desc, expected_ctrl, expected_data);
    end else begin
      $display("  RESULT : FAIL - %s", desc);
      $display("           Expected ctrl=%b data=0x%h",
        expected_ctrl, expected_data);
      $display("           Got     ctrl=%b data=0x%h",
        forward_rs1_ctrl_tb, forward_rs1_data_tb);
    end
  endtask


  initial begin

    $display("==========================================================");
    $display("  HAZARD DETECTION AND FORWARDING UNIT TEST BENCH");
    $display("  Modules: as_hazard_detection_unit, as_forwarding_unit");
    $display("  Stall signals ACTIVE LOW: 0=STALL, 1=NO STALL");
    $display("==========================================================");

    // Initialize all signals
    if_id_rs1_addr_tb    = 5'b0;
    if_id_rs2_addr_tb    = 5'b0;
    id_ex_rs1_addr_tb    = 5'b0;
    id_ex_rs2_addr_tb    = 5'b0;
    id_ex_rd_addr_tb     = 5'b0;
    id_ex_reg_wr_tb      = 1'b0;
    id_ex_mem_rd_tb      = 1'b0;
    ex_mem_rd_addr_tb    = 5'b0;
    ex_mem_reg_wr_tb     = 1'b0;
    ex_mem_mem_rd_tb     = 1'b0;
    mem_wb_rd_addr_tb    = 5'b0;
    mem_wb_reg_wr_tb     = 1'b0;
    id_ex_alu_result_tb  = 64'h0;
    ex_mem_alu_result_tb = 64'h0;
    mem_wb_result_tb     = 64'h0;

    #30;
    cycle_count = 0;

    //========================================================================
    // TEST 1: NO HAZARD
    // IF/ID needs r2, r3. ID/EX writes r1. No conflict.
    // Expected: No stall (stall_id_tb = 1), no forwarding (ctrl = 00)
    //========================================================================
    print_header("TEST 1 - No Hazard - Independent Instructions");

    if_id_rs1_addr_tb = 5'd2;
    if_id_rs2_addr_tb = 5'd3;

    id_ex_rd_addr_tb  = 5'd1;
    id_ex_reg_wr_tb   = 1'b1;
    id_ex_mem_rd_tb   = 1'b0;
    id_ex_rs1_addr_tb = 5'd0;
    id_ex_rs2_addr_tb = 5'd0;

    ex_mem_rd_addr_tb = 5'd0;
    ex_mem_reg_wr_tb  = 1'b0;
    ex_mem_mem_rd_tb  = 1'b0;

    mem_wb_rd_addr_tb = 5'd0;
    mem_wb_reg_wr_tb  = 1'b0;

    #10;
    cycle_count++;
    print_state("TEST 1");
    verify_hazard("No stall expected", 1'b0);

    verify_forward("No forwarding expected", 2'b00, 64'h0);

    //========================================================================
    // TEST 2: RAW HAZARD - ADD then SUB
    // IF/ID: SUB needs r1 as rs1
    // ID/EX: ADD writes r1 (reg_wr=1, mem_rd=0)
    // Expected: Stall (stall_id_tb = 0), forward from EX (ctrl = 01)
    //========================================================================
    print_header("TEST 2 - RAW Hazard - ADD r1 then SUB needs r1");

    if_id_rs1_addr_tb    = 5'd1;
    if_id_rs2_addr_tb    = 5'd5;

    id_ex_rd_addr_tb     = 5'd1;
    id_ex_reg_wr_tb      = 1'b1;
    id_ex_mem_rd_tb      = 1'b0;
    id_ex_alu_result_tb  = 64'h0000000000000030;

    ex_mem_rd_addr_tb    = 5'd0;
    ex_mem_reg_wr_tb     = 1'b0;
    ex_mem_mem_rd_tb     = 1'b0;

    mem_wb_rd_addr_tb    = 5'd0;
    mem_wb_reg_wr_tb     = 1'b0;

    #10;
    cycle_count++;
    print_state("TEST 2");

verify_hazard("No stall expected - resolved by forwarding", 1'b0);
verify_forward("Forward from EX stage expected", 2'b01, 64'h0000000000000030);

    //========================================================================
    // TEST 3: LOAD-USE HAZARD
    // IF/ID: SUB needs r1
    // EX/MEM: LW r1 (load instruction, mem_rd=1)
    // Expected: Stall (stall_id_tb = 0), no forwarding (load data not ready)
    //========================================================================
    print_header("TEST 3 - Load-Use Hazard - LW r1 then SUB needs r1");

    if_id_rs1_addr_tb    = 5'd1;
    if_id_rs2_addr_tb    = 5'd5;

    id_ex_rd_addr_tb     = 5'd0;
    id_ex_reg_wr_tb      = 1'b0;
    id_ex_mem_rd_tb      = 1'b0;
    id_ex_alu_result_tb  = 64'h0;

    ex_mem_rd_addr_tb    = 5'd1;
    ex_mem_reg_wr_tb     = 1'b1;
    ex_mem_mem_rd_tb     = 1'b1;
    ex_mem_alu_result_tb = 64'h0000000000000100;

    mem_wb_rd_addr_tb    = 5'd0;
    mem_wb_reg_wr_tb     = 1'b0;

    #10;
    cycle_count++;
    print_state("TEST 3");
    
    verify_hazard("Stall expected due to load-use hazard", 1'b1);
    
    verify_forward("No forwarding - load data not ready", 2'b00, 64'h0);

    //========================================================================
    // TEST 4: FORWARDING FROM EX STAGE (ALU result)
    // IF/ID: SUB needs r1
    // ID/EX: ADD r1, result = 0x30 (reg_wr=1, mem_rd=0)
    // Expected: Stall (RAW hazard), forward ctrl = 01
    //========================================================================
    print_header("TEST 4 - Forwarding from EX Stage");

    if_id_rs1_addr_tb    = 5'd1;
    if_id_rs2_addr_tb    = 5'd5;

    id_ex_rd_addr_tb     = 5'd1;
    id_ex_reg_wr_tb      = 1'b1;
    id_ex_mem_rd_tb      = 1'b0;
    id_ex_alu_result_tb  = 64'h0000000000000030;

    ex_mem_rd_addr_tb    = 5'd0;
    ex_mem_reg_wr_tb     = 1'b0;
    ex_mem_mem_rd_tb     = 1'b0;

    mem_wb_rd_addr_tb    = 5'd0;
    mem_wb_reg_wr_tb     = 1'b0;

    #10;
    cycle_count++;
    print_state("TEST 4");

verify_hazard("No stall expected - EX forwarding resolves RAW hazard", 1'b0);
verify_forward("Forward from EX stage", 2'b01, 64'h0000000000000030);

    //========================================================================
    // TEST 5: FORWARDING FROM EX/MEM STAGE (Non-Load ALU result)
    // IF/ID: AND needs r1
    // EX/MEM: SUB r1 result = 0x22 (reg_wr=1, mem_rd=0, NOT a load)
    // Expected: No stall, forward ctrl = 10
    //========================================================================
    print_header("TEST 5 - Forwarding from EX/MEM Stage (Non-Load)");

    if_id_rs1_addr_tb    = 5'd1;
    if_id_rs2_addr_tb    = 5'd7;

    id_ex_rd_addr_tb     = 5'd0;
    id_ex_reg_wr_tb      = 1'b0;
    id_ex_mem_rd_tb      = 1'b0;
    id_ex_alu_result_tb  = 64'h0;

    ex_mem_rd_addr_tb    = 5'd1;
    ex_mem_reg_wr_tb     = 1'b1;
    ex_mem_mem_rd_tb     = 1'b0;
    ex_mem_alu_result_tb = 64'h0000000000000022;

    mem_wb_rd_addr_tb    = 5'd0;
    mem_wb_reg_wr_tb     = 1'b0;

    #10;
    cycle_count++;
    print_state("TEST 5");
    
    verify_hazard("No stall - forwarding from EX/MEM handles it", 1'b0);
    
    verify_forward("Forward from EX/MEM stage", 2'b10, 64'h0000000000000022);

    //========================================================================
    // TEST 6: FORWARDING FROM MEM/WB STAGE
    // IF/ID: OR needs r1
    // MEM/WB: AND r1 result = 0x10 (reg_wr=1)
    // Expected: No stall, forward ctrl = 11
    //========================================================================
    print_header("TEST 6 - Forwarding from MEM/WB Stage");

    if_id_rs1_addr_tb    = 5'd1;
    if_id_rs2_addr_tb    = 5'd9;

    id_ex_rd_addr_tb     = 5'd0;
    id_ex_reg_wr_tb      = 1'b0;
    id_ex_mem_rd_tb      = 1'b0;
    id_ex_alu_result_tb  = 64'h0;

    ex_mem_rd_addr_tb    = 5'd0;
    ex_mem_reg_wr_tb     = 1'b0;
    ex_mem_mem_rd_tb     = 1'b0;
    ex_mem_alu_result_tb = 64'h0;

    mem_wb_rd_addr_tb    = 5'd1;
    mem_wb_reg_wr_tb     = 1'b1;
    mem_wb_result_tb     = 64'h0000000000000010;

    #10;
    cycle_count++;
    print_state("TEST 6");
    
    verify_hazard("No stall - data available in MEM/WB", 1'b0);
    
    verify_forward("Forward from MEM/WB stage", 2'b11, 64'h0000000000000010);

    //========================================================================
    // TEST 7: NO FORWARD FOR LOAD IN EX/MEM
    // IF/ID: SUB needs r1
    // EX/MEM: LW r1 (load, mem_rd=1) - data comes from memory, not ready
    // Expected: Stall, no forwarding (ctrl = 00)
    //========================================================================
    print_header("TEST 7 - No Forward for Load in EX/MEM Stage");

    if_id_rs1_addr_tb    = 5'd1;
    if_id_rs2_addr_tb    = 5'd5;

    id_ex_rd_addr_tb     = 5'd0;
    id_ex_reg_wr_tb      = 1'b0;
    id_ex_mem_rd_tb      = 1'b0;
    id_ex_alu_result_tb  = 64'h0;

    ex_mem_rd_addr_tb    = 5'd1;
    ex_mem_reg_wr_tb     = 1'b1;
    ex_mem_mem_rd_tb     = 1'b1;
    ex_mem_alu_result_tb = 64'h0000000000000100;

    mem_wb_rd_addr_tb    = 5'd0;
    mem_wb_reg_wr_tb     = 1'b0;

    #10;
    cycle_count++;
    print_state("TEST 7");
    
    verify_hazard("Stall expected - load data not ready in EX/MEM", 1'b1);

    verify_forward("No forwarding - load data from memory not available", 2'b00, 64'h0);

    //========================================================================
    // TEST COMPLETE
    //========================================================================
    #10;
    $display("==========================================================");
    $display("  TEST SUITE COMPLETE - 7 TEST CASES EXECUTED");
    $display("  Stall Active Low: stall_id=0 means STALL, stall_id=1 means NO STALL");
    $display("  Forward Ctrl: 00=RegFile 01=EX 10=EX/MEM 11=MEM/WB");
    $display("==========================================================");

    $finish;

  end

endmodule : as_tb
