`timescale 1ns/1ps

import as_pack::*;

module as_hazard_detection_unit (

  input  logic [4:0]  if_id_rs1_addr_i,
  input  logic [4:0]  if_id_rs2_addr_i,

  input  logic [4:0]  id_ex_rs1_addr_i,
  input  logic [4:0]  id_ex_rs2_addr_i,
  input  logic [4:0]  id_ex_rd_addr_i,
  input  logic        id_ex_reg_wr_i,
  input  logic        id_ex_mem_rd_i,

  input  logic [4:0]  ex_mem_rd_addr_i,
  input  logic        ex_mem_reg_wr_i,
  input  logic        ex_mem_mem_rd_i,

  input  logic [4:0]  mem_wb_rd_addr_i,
  input  logic        mem_wb_reg_wr_i,

  output logic        stall_if_o,
  output logic        stall_id_o,
  output logic        flush_ex_o
);

  logic hazard_exmem_load_s;

  assign hazard_exmem_load_s =
      ex_mem_mem_rd_i &&
      ex_mem_reg_wr_i &&
      (ex_mem_rd_addr_i != 5'b00000) &&
      ((ex_mem_rd_addr_i == if_id_rs1_addr_i) ||
       (ex_mem_rd_addr_i == if_id_rs2_addr_i));

  always_comb begin
    stall_if_o = 1'b1;
    stall_id_o = 1'b1;
    flush_ex_o = 1'b0;

    if (hazard_exmem_load_s) begin
      stall_if_o = 1'b0;
      stall_id_o = 1'b0;
      flush_ex_o = 1'b1;
    end
  end

endmodule