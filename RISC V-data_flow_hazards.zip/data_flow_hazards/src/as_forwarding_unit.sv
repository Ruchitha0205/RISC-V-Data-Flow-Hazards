`timescale 1ns/1ps

import as_pack::*;

module as_forwarding_unit (

  input  logic [4:0]        if_id_rs1_addr_i,
  input  logic [4:0]        if_id_rs2_addr_i,

  input  logic [4:0]        id_ex_rd_addr_i,
  input  logic              id_ex_reg_wr_i,
  input  logic [reg_width-1:0] id_ex_alu_result_i,
  input  logic              id_ex_mem_rd_i,

  input  logic [4:0]        ex_mem_rd_addr_i,
  input  logic              ex_mem_reg_wr_i,
  input  logic [reg_width-1:0] ex_mem_alu_result_i,
  input  logic              ex_mem_mem_rd_i,

  input  logic [4:0]        mem_wb_rd_addr_i,
  input  logic              mem_wb_reg_wr_i,
  input  logic [reg_width-1:0] mem_wb_result_i,

  output logic [1:0]        forward_rs1_ctrl_o,
  output logic [1:0]        forward_rs2_ctrl_o,

  output logic [reg_width-1:0] forward_rs1_data_o,
  output logic [reg_width-1:0] forward_rs2_data_o
);

  //================ RS1 =================
  always_comb begin
    forward_rs1_ctrl_o = 2'b00;
    forward_rs1_data_o = '0;

    if ((if_id_rs1_addr_i != 5'b00000) &&
        id_ex_reg_wr_i &&
        (id_ex_rd_addr_i == if_id_rs1_addr_i)) begin
      forward_rs1_ctrl_o = 2'b01;
      forward_rs1_data_o = id_ex_alu_result_i;
    end

    else if ((if_id_rs1_addr_i != 5'b00000) &&
             ex_mem_reg_wr_i &&
             (ex_mem_rd_addr_i == if_id_rs1_addr_i) &&
             !ex_mem_mem_rd_i) begin
      forward_rs1_ctrl_o = 2'b10;
      forward_rs1_data_o = ex_mem_alu_result_i;
    end

    else if ((if_id_rs1_addr_i != 5'b00000) &&
             mem_wb_reg_wr_i &&
             (mem_wb_rd_addr_i == if_id_rs1_addr_i)) begin
      forward_rs1_ctrl_o = 2'b11;
      forward_rs1_data_o = mem_wb_result_i;
    end
  end

  //================ RS2 =================
  always_comb begin
    forward_rs2_ctrl_o = 2'b00;
    forward_rs2_data_o = '0;

    if ((if_id_rs2_addr_i != 5'b00000) &&
        id_ex_reg_wr_i &&
        (id_ex_rd_addr_i == if_id_rs2_addr_i)) begin
      forward_rs2_ctrl_o = 2'b01;
      forward_rs2_data_o = id_ex_alu_result_i;
    end

    else if ((if_id_rs2_addr_i != 5'b00000) &&
             ex_mem_reg_wr_i &&
             (ex_mem_rd_addr_i == if_id_rs2_addr_i) &&
             !ex_mem_mem_rd_i) begin
      forward_rs2_ctrl_o = 2'b10;
      forward_rs2_data_o = ex_mem_alu_result_i;
    end

    else if ((if_id_rs2_addr_i != 5'b00000) &&
             mem_wb_reg_wr_i &&
             (mem_wb_rd_addr_i == if_id_rs2_addr_i)) begin
      forward_rs2_ctrl_o = 2'b11;
      forward_rs2_data_o = mem_wb_result_i;
    end
  end

endmodule